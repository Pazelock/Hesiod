bl_info = {
    "name": "Hesiod Heightmap Streamer",
    "author": "Hesiod",
    "version": (1, 9),
    "blender": (4, 2, 0),
    "category": "Object",
}

import re
import time
import socket
import struct
import zlib
import numpy as np
import threading
import bpy
from mathutils import Vector

HOST = "127.0.0.1"
Z_SCALE = 0.12 #this is a constant.

_thread = None
_connected = False
_sock = None
_terrain_state: dict[int, dict] = {}

# Debounce so a wave of several tiles updating together (e.g. multiple
# bridge nodes at once) triggers exactly one auto-arrange pass, once the
# wave has settled, instead of one per tile.
_AUTOARRANGE_DEBOUNCE = 0.3  # seconds
_autoarrange_pending = False

# ============================================================
# PER-TERRAIN NAMING
# ============================================================


def plane_name(tid: int) -> str:
    return f"TerrainTile_{tid}"


def image_name(tid: int) -> str:
    return f"HesiodTexture_{tid}"


def material_name(tid: int) -> str:
    return f"HesiodMat_{tid}"


def tex_node_name(tid: int) -> str:
    return f"HesiodTexNode_{tid}"


# ============================================================
# SAFE GETTERS
# ============================================================


def get_accumulate():
    return bpy.context.scene.hesiod_accumulate


def get_normalize_scale():
    return bpy.context.scene.hesiod_normalize_scale


def get_autoarrange():
    return bpy.context.scene.hesiod_autoarrange


def get_arrange_spacing():
    return bpy.context.scene.hesiod_arrange_spacing


# ============================================================
# ORDER NUMBERING (lowest free number per terrain id)
# ============================================================

_TILE_NAME_PATTERN = re.compile(r"^TerrainTile_(\d+)_(\d+)$")


def used_orders_for(tid: int) -> set:
    """Scans the scene for every TerrainTile_<tid>_<n> object and returns
    the set of n values already in use. Scanning the real scene (rather
    than trusting an in-memory counter) means numbering stays correct even
    after objects are deleted, or across a New Project in the same Blender
    session."""
    prefix = f"TerrainTile_{tid}_"
    used = set()
    for obj in bpy.data.objects:
        if not obj.name.startswith(prefix):
            continue
        # Strip any Blender-added .001 style suffix before parsing the number
        base_name = obj.name.split(".")[0]
        m = _TILE_NAME_PATTERN.match(base_name)
        if m and int(m.group(1)) == tid:
            used.add(int(m.group(2)))
    return used


def lowest_free_number(tid: int, exclude: set = frozenset()) -> int:
    """Returns the lowest positive integer not already used as an order
    number for this terrain id (ignoring numbers in `exclude`, so a tile
    about to be freed up - e.g. renamed away - doesn't block its own slot)."""
    used = used_orders_for(tid) - exclude
    n = 1
    while n in used:
        n += 1
    return n


# ============================================================
# AUTO-ARRANGE
# ============================================================


def _run_autoarrange():
    """Timer callback: selects every object with 'TerrainTile' in its name
    and runs Arrange on the whole set."""
    global _autoarrange_pending
    _autoarrange_pending = False

    tiles = [o for o in bpy.data.objects if "TerrainTile" in o.name]
    if not tiles:
        return None

    for o in bpy.context.selected_objects:
        o.select_set(False)
    for o in tiles:
        o.select_set(True)
    bpy.context.view_layer.objects.active = tiles[0]

    bpy.ops.hesiod.arrange_selection()
    return None  # don't reschedule


def schedule_autoarrange():
    """Debounces auto-arrange so a wave of several tiles updating together
    triggers exactly one arrange pass, once the wave has settled."""
    global _autoarrange_pending
    if _autoarrange_pending:
        return
    _autoarrange_pending = True
    bpy.app.timers.register(_run_autoarrange,
                            first_interval=_AUTOARRANGE_DEBOUNCE)


# ============================================================
# NETWORKING
# ============================================================


def recv_all(sock, size):
    data = b""
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            return None
        data += chunk
    return data


def stream_loop(port):
    global _connected, _sock

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _sock = sock

    try:
        sock.connect((HOST, port))
        _connected = True
        print(f"[Hesiod] Connected on port {port}")

        while True:

            # ------------------------
            # HEADER
            # ------------------------

            header = recv_all(sock, 20)
            if not header:
                break

            tid, width, height, hm_size, has_texture = struct.unpack(
                "IIIII", header)

            print(f"[Hesiod] Received terrain id={tid} ({width}x{height})")

            # ------------------------
            # HEIGHTMAP
            # ------------------------

            compressed_hm = recv_all(sock, hm_size)
            if compressed_hm is None:
                break

            raw_hm = zlib.decompress(compressed_hm)
            heightmap = np.frombuffer(raw_hm, dtype=np.float32).reshape(
                (height, width))

            rgba = None

            # ------------------------
            # TEXTURE
            # ------------------------

            if has_texture:
                tex_size_bytes = recv_all(sock, 4)
                if tex_size_bytes is None:
                    break

                tex_size = struct.unpack("I", tex_size_bytes)[0]

                compressed_rgba = recv_all(sock, tex_size)
                if compressed_rgba is None:
                    break

                raw_rgba = zlib.decompress(compressed_rgba)
                rgba = np.frombuffer(raw_rgba, dtype=np.float32).reshape(
                    (height, width, 4))

            bpy.app.timers.register(
                lambda hm=heightmap, c=rgba, t=tid: update_mesh(t, hm, c))

    except Exception as e:
        print("[Hesiod] Socket error:", e)

    finally:
        _connected = False
        try:
            sock.close()
        except OSError:
            pass
        if _sock is sock:
            _sock = None
        print("[Hesiod] Disconnected")


# ============================================================
# MATERIAL / TEXTURE
# ============================================================


def ensure_material(tid: int, obj, width: int, height: int):
    mat_name = material_name(tid)
    mat = bpy.data.materials.get(mat_name)

    if mat is None:
        mat = bpy.data.materials.new(name=mat_name)
        mat.use_nodes = True

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()

        output = nodes.new("ShaderNodeOutputMaterial")
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        tex = nodes.new("ShaderNodeTexImage")
        tex.name = tex_node_name(tid)

        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
        links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)

    img_name = image_name(tid)
    img = bpy.data.images.get(img_name)
    if img is None or img.size[0] != width or img.size[1] != height:
        if img is not None:
            bpy.data.images.remove(img)
        img = bpy.data.images.new(img_name,
                                  width=width,
                                  height=height,
                                  alpha=True)
        img.colorspace_settings.name = 'sRGB'

    mat.node_tree.nodes[tex_node_name(tid)].image = img

    return img


def update_texture(img, rgba):
    flat = rgba.reshape(-1)
    img.pixels.foreach_set(flat)
    img.update()


# ============================================================
# MESH
# ============================================================


def normalize_domain_scale(obj):
    """Scale obj to 1x1m on X/Y (based on its current bounding box) and
    apply the scale transform. Used both by the manual operator and
    automatically on new tiles when 'Normalize scale' is enabled."""
    was_hidden = obj.hide_viewport
    obj.hide_viewport = False

    bbox = [Vector(corner) for corner in obj.bound_box]
    orig_dim_x = max(pt.x for pt in bbox) - min(pt.x for pt in bbox)
    orig_dim_y = max(pt.y for pt in bbox) - min(pt.y for pt in bbox)

    if orig_dim_x > 0:
        obj.scale.x *= (1.0 / orig_dim_x)
    if orig_dim_y > 0:
        obj.scale.y *= (1.0 / orig_dim_y)

    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.hide_viewport = was_hidden


def create_grid(tid: int, width: int, height: int):
    prefix = plane_name(tid)
    accumulate = get_accumulate()

    # Find the current live object for this terrain via tracked state,
    # since its name always carries a number postfix (TerrainTile_<tid>_<n>).
    prev_state = _terrain_state.get(tid)
    prev_name = prev_state.get("live_name") if prev_state else None
    prev_obj = bpy.data.objects.get(prev_name) if prev_name else None

    freed_numbers = set()
    if prev_obj is not None and not accumulate:
        # Not accumulating: delete the previous tile outright, silently
        # remembering when it was replaced. Freeing its slot lets the new
        # tile reuse the same number if it's still the lowest free one.
        prev_match = _TILE_NAME_PATTERN.match(prev_obj.name.split(".")[0])
        if prev_match:
            freed_numbers.add(int(prev_match.group(2)))
        _terrain_state.setdefault(tid, {})["last_replaced_at"] = time.time()
        bpy.data.objects.remove(prev_obj, do_unlink=True)
    elif prev_obj is not None and accumulate:
        # Accumulating: keep the previous tile. Normally hide it (Alt+H to
        # reveal); while Auto-arrange is on, tiles stay visible instead so
        # the arranged history remains visible in the viewport.
        if not get_autoarrange():
            prev_obj.hide_set(True)

    order = lowest_free_number(tid, exclude=freed_numbers)
    name = f"{prefix}_{order}"

    aspect = width / height

    bpy.ops.mesh.primitive_grid_add(
        x_subdivisions=width - 1,
        y_subdivisions=height - 1,
        size=1.0,
        calc_uvs=True,
        enter_editmode=False,
        align='WORLD',
        location=(0.0, 0.0, 0.0),
        rotation=(0.0, 0.0, 0.0),
    )

    obj = bpy.context.active_object
    obj.name = name
    obj["hesiod_width"] = width
    obj["hesiod_height"] = height
    obj["hesiod_tid"] = tid

    obj.scale.x = aspect
    obj.scale.y = 1.0
    obj.scale.z = 1.0

    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    if get_normalize_scale():
        normalize_domain_scale(obj)

    mesh = obj.data
    vertex_buffer = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", vertex_buffer)

    state = _terrain_state.setdefault(tid, {})
    state.update({
        "vertex_buffer": vertex_buffer,
        "mesh_width": width,
        "mesh_height": height,
        "live_name": obj.name,
    })

    print(f"[Hesiod] Created grid for terrain {tid}: "
          f"{width}x{height} ({len(mesh.vertices)} vertices)")

    if get_autoarrange():
        schedule_autoarrange()

    return obj


def update_mesh(tid: int, heightmap, rgba=None):
    height, width = heightmap.shape

    state = _terrain_state.get(tid)
    live_name = state.get("live_name") if state else None
    obj = bpy.data.objects.get(live_name) if live_name else None

    needs_new_grid = (obj is None or state is None
                      or state["mesh_width"] != width
                      or state["mesh_height"] != height
                      or get_accumulate())

    if needs_new_grid:
        obj = create_grid(tid, width, height)
        state = _terrain_state[tid]

    mesh = obj.data
    heights = heightmap.flatten().astype(np.float32) * Z_SCALE

    expected_vertices = len(mesh.vertices)
    if len(heights) != expected_vertices:
        print(f"[Hesiod] Terrain {tid} vertex mismatch: "
              f"{len(heights)} vs {expected_vertices}")
        return None

    state["vertex_buffer"][2::3] = heights
    mesh.vertices.foreach_set("co", state["vertex_buffer"])
    mesh.update()

    if rgba is not None:
        img = ensure_material(tid, obj, width, height)
        update_texture(img, rgba)

    return None


# ============================================================
# SESSION RESTORE
# ============================================================


def restore_terrain_state():
    """Rebuild _terrain_state from objects already in the scene (e.g. after
    a Blender restart). For each terrain id, the live tile is whichever
    matching object is not hidden - accumulate history tiles are always
    hidden, so there is exactly one visible tile per terrain id."""
    by_tid: dict[int, list] = {}
    for obj in bpy.data.objects:
        m = _TILE_NAME_PATTERN.match(obj.name.split(".")[0])
        if m is None:
            continue
        by_tid.setdefault(int(m.group(1)), []).append(obj)

    for tid, objs in by_tid.items():
        visible = [o for o in objs if not o.hide_get()]
        obj = visible[0] if visible else None
        if obj is None:
            # Everything for this tid is hidden (unexpected) - skip restore,
            # a future update will just create a fresh live tile.
            continue

        width = obj.get("hesiod_width")
        height = obj.get("hesiod_height")

        if width is None or height is None:
            print(
                f"[Hesiod] Terrain {tid} missing custom properties, skipping")
            continue

        mesh = obj.data
        vertex_buffer = np.empty(len(mesh.vertices) * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", vertex_buffer)

        _terrain_state[tid] = {
            "vertex_buffer": vertex_buffer,
            "mesh_width": int(width),
            "mesh_height": int(height),
            "live_name": obj.name,
        }

        print(f"[Hesiod] Restored terrain {tid}: {width}x{height}")

    return None


# ============================================================
# UI REFRESH TIMER
# ============================================================


def _refresh_ui() -> float:
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    return 1.0


# ============================================================
# STREAM CONTROL
# ============================================================


def start_stream(port):
    global _thread

    if _thread and _thread.is_alive():
        print("[Hesiod] Already running")
        return

    _thread = threading.Thread(target=stream_loop, args=(port, ), daemon=True)
    _thread.start()
    print(f"[Hesiod] Stream started on port {port}")


def disconnect_stream():
    global _sock

    if _sock is not None:
        try:
            _sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            _sock.close()
        except OSError:
            pass
        _sock = None
        print("[Hesiod] Disconnect requested")
    else:
        print("[Hesiod] Not connected")


# ============================================================
# OPERATORS
# ============================================================


class HESIOD_OT_start_stream(bpy.types.Operator):
    bl_idname = "hesiod.start_stream"
    bl_label = "Start Heightmap Stream"

    def execute(self, context):
        start_stream(context.scene.hesiod_port)
        return {'FINISHED'}


class HESIOD_OT_disconnect_stream(bpy.types.Operator):
    bl_idname = "hesiod.disconnect_stream"
    bl_label = "Disconnect"
    bl_description = "Close the current heightmap stream connection"

    def execute(self, context):
        disconnect_stream()
        self.report({'INFO'}, "Disconnected")
        return {'FINISHED'}


def tile_sort_key(obj):
    """Returns (tid, order) for a tile object, parsed from
    TerrainTile_<tid>_<order> (ignoring any .001-style Blender suffix)."""
    m = _TILE_NAME_PATTERN.match(obj.name.split(".")[0])
    if m is None:
        return (None, 0)
    return (int(m.group(1)), int(m.group(2)))


class HESIOD_OT_arrange_selection(bpy.types.Operator):
    bl_idname = "hesiod.arrange_selection"
    bl_label = "Arrange"
    bl_description = ("Reset rotation/position, then lay out selected tiles in a grid: "
                      "each terrain gets its own row (alphabetical by id, along Y), with "
                      "the highest-numbered (most recent) tile closest to X=0")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        spacing = get_arrange_spacing()

        # Reset rotation and position up front for every selected object,
        # using the object's origin directly (no bounding-box offset), so
        # layout always starts cleanly from (0, 0).
        for obj in selected:
            obj.hide_viewport = False
            obj.location = Vector((0.0, 0.0, 0.0))
            obj.rotation_euler = Vector((0.0, 0.0, 0.0))

        # Group tiles by terrain id.
        groups: dict[int, list] = {}
        for obj in selected:
            tid, order = tile_sort_key(obj)
            groups.setdefault(tid, []).append((order, obj))

        # Terrains are laid out along Y, in alphabetical order of their id
        # (as text, e.g. "10" sorts before "2").
        current_y = 0.0
        for tid in sorted(groups.keys(), key=lambda t: str(t)):
            # Highest order number first - it is the most recently
            # generated tile and sits closest to X=0.
            entries = sorted(groups[tid], key=lambda e: e[0], reverse=True)

            row_depth_y = 0.0
            current_x = 0.0
            for order, obj in entries:
                dims = obj.dimensions
                width_x = dims.x
                depth_y = dims.y
                row_depth_y = max(row_depth_y, depth_y)

                obj.location.x = current_x
                current_x += width_x + spacing

            for order, obj in entries:
                obj.location.y = current_y

            current_y += row_depth_y + spacing

        self.report({'INFO'}, f"Arranged {len(selected)} object(s)")
        return {'FINISHED'}


class HESIOD_OT_set_scale(bpy.types.Operator):
    bl_idname = "hesiod.set_scale"
    bl_label = "Set Scale"
    bl_description = ("Reset rotation and uniformly scale selected tiles "
                      "(same factor on all axes) so their height matches the target")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        target_height = context.scene.hesiod_target_height
        skipped = 0

        for obj in selected:
            was_hidden = obj.hide_viewport
            obj.hide_viewport = False

            obj.rotation_euler = Vector((0.0, 0.0, 0.0))

            bbox = [Vector(corner) for corner in obj.bound_box]
            current_height = max(pt.z for pt in bbox) - min(pt.z for pt in bbox)

            if current_height > 0:
                factor = target_height / current_height
                obj.scale.x *= factor
                obj.scale.y *= factor
                obj.scale.z *= factor
            else:
                skipped += 1

            obj.hide_viewport = was_hidden

        msg = (f"Set height to {target_height:.3f} for "
              f"{len(selected) - skipped} object(s) - scale was not applied")
        if skipped:
            msg += f" ({skipped} skipped, zero height)"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ============================================================
# UI PANEL
# ============================================================


class HESIOD_PT_panel(bpy.types.Panel):
    bl_label = "Hesiod Stream"
    bl_idname = "HESIOD_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Hesiod Heightmap Streamer"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Connection indicator
        row = layout.row()
        if _connected:
            row.label(text="● Connected", icon='CHECKMARK')
        else:
            row.label(text="○ Disconnected", icon='X')

        layout.separator()
        layout.prop(scene, "hesiod_port")

        row = layout.row(align=True)
        row.operator("hesiod.start_stream",
                     text="Reconnect" if _connected else "Connect")
        row.operator("hesiod.disconnect_stream")

        layout.separator()
        layout.prop(scene, "hesiod_accumulate")
        layout.prop(scene, "hesiod_normalize_scale")
        layout.prop(scene, "hesiod_autoarrange")

        layout.separator()
        layout.label(text="Tools:")
        layout.prop(scene, "hesiod_arrange_spacing")
        layout.operator("hesiod.arrange_selection", icon='ALIGN_CENTER')

        layout.separator()
        layout.prop(scene, "hesiod_target_height")
        layout.operator("hesiod.set_scale", icon='FULLSCREEN_ENTER')


# ============================================================
# REGISTER
# ============================================================

classes = (
    HESIOD_OT_start_stream,
    HESIOD_OT_disconnect_stream,
    HESIOD_OT_arrange_selection,
    HESIOD_OT_set_scale,
    HESIOD_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.hesiod_port = bpy.props.IntProperty(
        name="Port",
        default=9001,
        min=1024,
        max=65535,
    )
    bpy.types.Scene.hesiod_accumulate = bpy.props.BoolProperty(
        name="Accumulate Meshes",
        description="Keep old generated meshes hidden instead of deleting them when terrain updates",
        default=False,
    )
    bpy.types.Scene.hesiod_normalize_scale = bpy.props.BoolProperty(
        name="Normalize Scale",
        description="Automatically scale every new tile to 1x1m on X/Y as soon as it's created",
        default=True,
    )
    bpy.types.Scene.hesiod_arrange_spacing = bpy.props.FloatProperty(
        name="Arrange Spacing",
        description="Gap left between tiles when arranging (both between a terrain's history steps and between terrain rows)",
        default=0.0,
        min=0.0,
    )
    bpy.types.Scene.hesiod_target_height = bpy.props.FloatProperty(
        name="Target Height",
        description="Desired Z-axis height used by Set Scale",
        default=1.0,
        min=0.0,
    )
    bpy.types.Scene.hesiod_autoarrange = bpy.props.BoolProperty(
        name="Auto-arrange",
        description=("Automatically arrange every newly generated tile. While enabled, "
                    "newly generated meshes are also kept visible instead of being hidden"),
        default=False,
    )

    if not bpy.app.timers.is_registered(_refresh_ui):
        bpy.app.timers.register(_refresh_ui,
                                first_interval=1.0,
                                persistent=True)

    # Defer until bpy.data is fully accessible
    bpy.app.timers.register(restore_terrain_state, first_interval=0.1)


def unregister():
    if bpy.app.timers.is_registered(_refresh_ui):
        bpy.app.timers.unregister(_refresh_ui)

    del bpy.types.Scene.hesiod_port
    del bpy.types.Scene.hesiod_accumulate
    del bpy.types.Scene.hesiod_normalize_scale
    del bpy.types.Scene.hesiod_arrange_spacing
    del bpy.types.Scene.hesiod_target_height
    del bpy.types.Scene.hesiod_autoarrange

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()